{{/*
Expand the name of the chart.
*/}}
{{- define "marple.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "marple.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "marple.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Base selector labels for the API pod (unchanged across chart upgrades).
*/}}
{{- define "marple.selectorLabels" -}}
app.kubernetes.io/name: {{ include "marple.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
App name label for the queue worker pod (separate from API so selectors stay distinct).
*/}}
{{- define "marple.queueName" -}}
{{- printf "%s-queue" (include "marple.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels for the queue worker pod.
*/}}
{{- define "marple.queueSelectorLabels" -}}
app.kubernetes.io/name: {{ include "marple.queueName" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "marple.labels" -}}
helm.sh/chart: {{ include "marple.chart" . }}
{{ include "marple.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Labels for the queue worker pod.
*/}}
{{- define "marple.queueLabels" -}}
helm.sh/chart: {{ include "marple.chart" . }}
{{ include "marple.queueSelectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Render container resources from a {requests, limits} values block.
Omit limits when unset to match Docker profile behaviour (0 = unlimited).
*/}}
{{- define "marple.containerResources" -}}
{{- $r := . -}}
{{- $hasRequests := and $r.requests (or $r.requests.cpu $r.requests.memory) -}}
{{- $hasLimits := and $r.limits (or $r.limits.cpu $r.limits.memory) -}}
{{- if or $hasRequests $hasLimits }}
resources:
  {{- if $hasRequests }}
  requests:
    {{- with $r.requests.cpu }}
    cpu: {{ . }}
    {{- end }}
    {{- with $r.requests.memory }}
    memory: {{ . }}
    {{- end }}
  {{- end }}
  {{- if $hasLimits }}
  limits:
    {{- with $r.limits.cpu }}
    cpu: {{ . }}
    {{- end }}
    {{- with $r.limits.memory }}
    memory: {{ . }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Internal API URL for Playwright exports from the queue pod.
Defaults to the API Service DNS name (http://<release>-marple).
*/}}
{{- define "marple.exportServerUrl" -}}
{{- .Values.export.serverUrl | default (printf "http://%s" (include "marple.fullname" .)) }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "marple.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "marple.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
